# mcis6273-f23-datamining
**Zetero UserName: akodegandlushiva**

**GitHub UserName: akodegandlushiva**

***repo Link: https://github.com/akodegandlushiva/mcis6273_f23_datamining.git***

